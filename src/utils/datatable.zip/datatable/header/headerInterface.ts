

export interface HeaderInterface {
    text:string
    key:string
    isPrice?:boolean
    isImage?:boolean
    total?:number
    generateColumnHtml:Function
}