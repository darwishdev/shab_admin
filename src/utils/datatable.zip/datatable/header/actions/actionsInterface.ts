

export interface ActionsParamInterface {
    edit : boolean
    delete : boolean
    view : boolean
}